'use strict';
const shim = require('fabric-shim');
const util = require('util');

var Chaincode = class {
    
    /**

    //university struct 
    let university = {
        'docType': string, default 'university', //docType used to distinguish the various objects in state database
        'title': string
        'universityID': integer
    };

    //course struct
    let course {
        'docType': string, default 'course', //docType used to distinguish the various objects in state database
        'name': string
        'courseCode': string
        'universityID': integer
        'classGPA': double
        'units': double
    };

    //student struct
    let student = {
        'docType': string, default 'student' //docType used to distinguish the various objects in state database
        'fname': string
        'lname': string
        'id': string
        'courses': [{course objects}, ...]
    };
     
    **/
    // Initialize the chaincode
    async Init(stub) {
        console.info('========= example cardealer Init =========');
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        return shim.success();
    }

    async Invoke(stub) {
        console.info('Transaction ID: ' + stub.getTxID());
        let ret = stub.getFunctionAndParameters();
        console.info(ret);
        let method = this[ret.fcn];
        if (!method) {
            console.error('no method of name:' + ret.fcn + ' found');
            throw new Error('Received unknown function ' + ret.fcn + ' invocation');
        }

        console.info('\nCalling method : ' + ret.fcn);
        try {
            let payload = await method(stub, ret.params, this);
            return shim.success(payload);
        } catch (err) {
            console.log(err);
            return shim.error(err);
        }
    }

    // =======================================================================
    // initStudent - create a new student, store into chaincode state
    // =======================================================================
    async initStudent(stub, args, thisClass) {
        // data model with recall fields
        //    0       1            2                                                3          
        // "john", "tanner", "7221054840", "[{'name':'Data Structures', 'courseCode': 'csci104', 'universityID': 4312, 'classGPA': 3.5, 'units': 4 }, ...]"

        let student = {};
        let jsonRes = {};
        student.docType = 'student';

        if(args.length != 3) { //4 = old version
            throw new Error('Incorrect number of arguments. Expecting 3');
        }

        console.info('- start init student');
        if(args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if(args[1].length <= 0) {
            throw new Error('2nd argument must be a non-empty string');
        }
        if(args[2].length != 12) {
            throw new Error('3rd argument must be a exactly 12 digits');
        }

        student.fname = args[0];
        student.lname = args[1];
        student.id = args[2];

        student.courses = [{'name':'CSCI 104', 'courseCode': '5c690185edc8c220d49f6263', 'universityID': 4312, 'classGPA': 3.5, 'units': 4 },
        {'name':'CSCI 570', 'courseCode': '5c698004f4a53026914aa2c8', 'universityID': 4312, 'classGPA': 4.0, 'units': 4 }];

        // student.id = parseInt(args[2]);
        // if(typeof student.id !== 'number'){
        //     throw new Error('3rd argument must be a numeric string');        
        // }
        
        // const re = /{:\s|,\s}/;
        // let obj = (args[3]).split(re);
        // student.courses = JSON.parse(obj);

        // if(student.courses.length <= 0) {
        //     throw new Error('4th argument must be a non-empty array of completed course objects');
        // }

        //check if student already exists
        let studentAsBytes = await stub.getState(student.id);
        if (studentAsBytes.toString()){
            console.info('This student already exists: ' + student.id);
            jsonResp.Error = 'This student already exists: ' + student.id;
            throw new Error(JSON.stringify(jsonResp));
        }

        // ==== Create student object and marshal to JSON ====    
        let studentJSONasBytes = Buffer.from(JSON.stringify(student));
    
        // === Save student to state ===
        console.info('Save student:', JSON.stringify(student));
        
        // Write the states back to the ledger
        await stub.putState(student.id, studentJSONasBytes);
        
        console.info('- end initStudent(success)');
    }

    // =================================================
    // readStudent- read a student from chaincode state
    // =================================================
    async readStudent(stub, args, thisClass) {
        let jsonResp = {};
        if (args.length != 1) {
            throw new Error("Incorrect number of arguments. Expecting id number of student to query");
        }
        if (args[0].length != 12) {
            throw new Error("1st argument must be a exactly 12 digits");
        }
    
        let idNumber = args[0];

        // if(typeof idNumber !== 'number'){
        //     throw new Error('1st argument must be a numeric string');        
        // }
        
        let idNumberAsbytes = await stub.getState(idNumber); //get the student from chaincode state
        if (!idNumberAsbytes.toString()) {
            console.info("Failed to get state for " + idNumber);
            jsonResp.Error = "Failed to get state for " + idNumber;
            throw new Error(JSON.stringify(jsonResp));
        } 

        return idNumberAsbytes;
    } 

    // ==========================================================
    // updateStudentCourses: update a students completed courses
    // ==========================================================

    async updateStudentCourses(stub, args, thisClass) {
        let jsonResp = {};
        //   0                                              1       
        // "id", "[{'name':'Data Structures', 'courseCode': 'csci104', 'classGPA': 3.5, 'units': 4 }, ...]",
        if (args.length != 2) {
            throw new Error("Incorrect number of arguments. Expecting 2");
        }

        if(args[0].length != 12) {
            throw new Error('3rd argument must be a exactly 12 digits');
        }

        let idNumber = parseInt(args[0]);
        
        if(typeof idNumber !== 'number'){
            throw new Error('3rd argument must be a numeric string');        
        }

        const re = /{:\s|,\s}/;
        let obj = (args[1]).split(re);
        let newCourses = JSON.parse(obj);

        if(newCourses.length <= 0) {
            throw new Error('4th argument must be a non-empty array of completed course objects');
        }
        
        console.info("Updating completed courses for student with id number: " + idNumber);
        let studentAsBytes = await stub.getState(idNumber);
        if (!studentAsBytes.toString()) {
            console.info("Failed to get student:" + idNumber);
            jsonResp.Error = "Failed to get student:" + idNumber;
            throw new Error(JSON.stringify(jsonResp));
        }

        let studentToUpdate = {};
        try{
            studentToUpdate = JSON.parse(studentAsBytes.toString('utf8'));
        }catch(err){
            console.info("Failed to decode :" + idNumber);
            jsonResp.Error = "Failed to decode vehicle:" + idNumber;
            throw new Error(JSON.stringify(jsonResp));
        }

        studentToUpdate.courses = newCourses; //change the course list

        //update world state
        let studentJSONBytes = Buffer.from(JSON.stringify(studentToUpdate));

        await stub.putState(idNumber, studentJSONBytes); //rewrite the student

        console.info("- end updateStudent (success)");
    }

    // ============================================================
    // initUniversity - create a new university , store into chaincode state
    // ============================================================       
    async initUniversity(stub, args, thisClass) {
        // data model with recall fields
        //   0               1          2
        // "title", "universityid=1234",  "[student1, student2, ...]"
        let university = {};
        let jsonResp = {};
        
        university.docType = 'university';
        
        if (args.length != 3) {
            throw new Error('Incorrect number of arguments. Expecting 2');
        }
        
        // ==== Input sanitation ====
        console.info('- start init university');
        if (args[0].length <= 0) {
            throw new Error('1st argument must be a non-empty string');
        }
        if (args[1].length < 4) {
            throw new Error('2nd argument must be a four digit integer');
        }
        if (args[2].length <= 2) {
            throw new Error('3rd argument must be a non-empty array');
        }
        
        university.title = args[0];
        university.universityid = parseInt(args[1]);

        const re = /{:\s|,\s}/;

        let stud_list = args[2].split(re);

        const students = JSON.parse(stud_list);

        university.students = students;

        // ==== Check if university already exists ====
        let universityAsBytes = await stub.getState(university.name);
        if (universityAsBytes.toString()){
            console.info('This university already exists: ' + university.name);
            jsonResp.Error = 'This university already exists: ' + university.name;
            throw new Error(JSON.stringify(jsonResp));
        }
        
        // ==== Create university object and marshal to JSON ====
        let universityJSONasBytes = Buffer.from(JSON.stringify(university));
        
        // === Save university to state ===
        await stub.putState(university.name, universityJSONasBytes);

        // ==== Vehicle part saved and indexed. Return success ====
        console.info('- end init university');
    }

    // =====================================================================================
    // updateUniversity: transfer a university  by setting a new owner name on the university
    // =====================================================================================
    async updateUniversity(stub, args, thisClass) {
        let jsonResp = {};
        //   0                 1       
        // "universityid", "students"
        
        if (args.length < 2) {
            throw new Error("Incorrect number of arguments. Expecting 2");
        }

        let universityid = parseInt(args[0]);
        let students = args[1];
        
        console.info("Transfering university with university id number: " + universityid + " With new students. " );
        let universityAsBytes = await stub.getState(universityid);
        if (!universityAsBytes.toString()) {
            console.info("Failed to get university:" + universityid);
            jsonResp.Error = "Failed to get university:" + universityid;
            throw new Error(JSON.stringify(jsonResp));
        }

        let universityToTransfer = {};
        try{
            universityToTransfer = JSON.parse(universityAsBytes.toString('utf8'));
        }catch(err){
            console.info("Failed to decode university:" + universityid);
            jsonResp.Error = "Failed to decode university:" + universityid;
            throw new Error(JSON.stringify(jsonResp));
        }

        // if currentOwner != universityToTransfer.Owner {
        //     return "This asset is currently owned by another entity.", err
        // }

        universityToTransfer.owner = newOwner; //change the owner

        //update world state
        let universityJSONBytes = Buffer.from(JSON.stringify(students));

        await stub.putState(universityid, universityJSONBytes); //rewrite the university

        console.info("- end transferVehicle (success)");

    }
    
    
    // ===========================================================================================
    // getHistoryForRecord returns the histotical state transitions for a given key of a record
    // ===========================================================================================
    // async getHistoryForRecord(stub, args, thisClass) {

    //     if (args.length < 1) {
    //         throw new Error("Incorrect number of arguments. Expecting 1");
    //     }

    //     let recordKey = args[0];

    //     console.info("- start getHistoryForRecord: %s\n", recordKey);

    //     let resultsIterator = await stub.getHistoryForKey(recordKey);
        
    //     // results is a JSON array containing historic values for the key/value pair
    //     let results = [];
    //     while (true){
    //         let res = await resultsIterator.next();
    //         let jsonRes = {};
            
    //         if (res.value && res.value.value.toString()) {
    //             console.log(res.value.value.toString('utf8'));
    //             jsonRes.TxId = res.value.tx_id;
    //             jsonRes.Timestamp = new Date(res.value.timestamp.seconds.low).toString();
    //             jsonRes.IsDelete = res.value.is_delete.toString();
    //             try {
    //                 jsonRes.Value = JSON.parse(res.value.value.toString('utf8'));
    //             } catch (err) {
    //                 console.log(err);
    //                 jsonRes.Value = res.value.value.toString('utf8');
    //             }
    //             results.push(jsonRes);
    //         }
    //         if(res.done){
    //             console.info('end of data');
    //             await resultsIterator.close();
    //             console.log("- getHistoryForRecord returning:\n", JSON.stringify(results));
                
    //             return Buffer.from(JSON.stringify(results));
    //         }
    //     }
    // }
    
};

shim.start(new Chaincode());